<template>
  <div class="wrapper">
    <img src="choosefood.jpg" alt="choosefood">

  <input type="button" @click=""
         value="מרק ערמונים עם פטריות וכרישה">
  <br>
  <input type="button" @click=""
         value="מרק עדשים">
  <br>
  <input type="button" @click=""
         value="פילה דג עם ירקות בתנור">
    <br/>
    <input type="button" @click=""
         value="סלומון בתנור בג'ינג'ר ודבש">
  <br/>
  <input type="button" @click=""
         value="שעועית ירוקה עם בטטה">
  <br>
  </div>
</template>
<body>

</body>
<script>
    export default {
        name: "chooseRecipe",
    data()
    {
      // return {
      //   image: {backgroundImage: "url(.../src/assets/choosefood.jpg)"}
      // };
    }
    };
</script>
<style scoped>
  .wrapper {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 360px;
    height: 640px;
    padding: 200px;
    margin: auto;
  }
</style>
<!--<style >-->
<!--.image {-->
<!--  width: 360px;-->
<!--  height: 640px;-->


}
