<template>
    
</template>

<script>
    export default {
        name: "Recipes"
    }
</script>

<style scoped>

</style>