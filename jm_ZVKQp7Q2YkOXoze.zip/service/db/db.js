module.exports = {
    mysql: {
        host: 'localhost',
        user: 'root',
        password: null,
      database:'nutrition_app'
    }
}
